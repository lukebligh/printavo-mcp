---
name: clint-cx-sweep
description: Clint's customer success sweep at Est Merch. Use when Clint says "CX sweep", "check my jobs", "who needs an update", "anything stuck", or asks about orders in progress, Printavo statuses, promo orders or Mechelle. Finds jobs that are stuck, at risk or overdue for a human update, and drafts the customer notes.
---

# CX Sweep — Est Merch, Clint

Once a job hits a production lane, the crew moves most statuses and Printavo's status automations email the customer. Clint's job is the human layer: keep every customer informed, catch problems before the customer does, and make sure nothing sits stuck.

**Sales still trumps this.** If the sweep turns up a new inquiry or quote request, put it at the top and tell him to handle it first.

## What to check

1. **Dates at risk.** Printavo `get_production_schedule` (next 7 business days) + `get_order_details`: scheduled date after the customer due date, or due within 3 business days with goods, art or proof not done. Promise 1: the customer hears it from us first. Draft the heads-up.
2. **Stuck jobs.** Jobs sitting in the same pre-production status (art, proof sent, waiting on approval, goods not in) for 3+ business days. Who owns the next move: the customer (nudge them), the crew (tell Clint who to ask), or Mechelle (sourcing).
3. **Proofs waiting on the customer.** Proof sent 2+ business days ago, not approved. Draft a short nudge with what happens to the date if it slips.
4. **Customers due a human update.** Direct jobs in progress, due this week, with no email from anyone at estmerch.com in the last 2 business days (check clint@, luke@ and sales@ by the customer's email). Draft a 2–3 line update.
5. **Ready and not picked up / shipped.** Jobs completed 2+ business days ago that are still sitting.
6. **Promo orders (Mechelle).** Promo / SAGE orders in progress: ordered, ship date, tracking. List what to confirm with Mechelle.
7. **Open problems.** Misprints, short-ships, complaints in the last 2 weeks. Promise 6: our error = free reprint, every time; anything past that goes to Luke.

## Drafting the customer notes
In clint@ Drafts, in his voice (`clints-voice` skill; if it isn't installed: short, friendly, plain, no em dashes, no "hope this finds you well"). Only facts from Printavo. Never invent a date or a reason; put `[new date?]` and flag it.
- On track: "[Name], quick update on your [job]… [where it is in plain words], still on track for [date]. I'll let you know the minute it's ready."
- At risk: "[Name], heads up on your [job]… [real reason]. [Fix + new date, only if known]. Wanted you to hear it from us first."
- Proof nudge: "[Name], your proof for the [job] is waiting on your OK. Approve by [day] and we stay on track for [date]."
- Ready: "[Name], your [job] is ready. [Pickup or shipping]."

## Output
Sections, only the ones with something in them, max 5 lines each, nearest due date first: *At risk* · *Stuck* · *Proofs waiting* · *Due an update* · *Ready, not out* · *Ask Mechelle* · *Open problems*. One line each: `#order · Customer · due M/D · the issue · next move`. Then offer to draft.

## Rules
- Contract jobs (UGP / Underground and other trade accounts) still get at-risk heads-ups to the contract customer, but no marketing.
- Never change a Printavo status or send an email unless Clint says so in this chat.
- `search_orders` returns results OLDEST FIRST and caps: limit 50+, read the end.
- Only what a tool showed you. If a connector fails, say which one in one line.

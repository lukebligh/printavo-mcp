---
name: clint-sales-sweep
description: Clint's sales sweep at Est Merch. Use when Clint says "sales sweep", "what deals need me", "who should I call", "check my pipeline", or asks about leads, quotes, the fall list or Rock 2. Finds every open opportunity that needs a touch, ranks it by dollars, and drafts the follow-ups in his voice.
---

# Sales Sweep — Est Merch, Clint

**Sales opportunities trump everything.** This sweep finds the ones that are slipping. Run it whenever Clint asks, as often as he likes.

## What to check (in this order)

0. **Margin check on quotes going out.** For any quote Clint is building or sent today, check it against the margin floor and price rules: the Nov 1, 2026 increase (+7% direct, +8–10% contract), DTF and InkSoft at 55% gross margin, contract jobs on the contract price list. Use the documented Est Merch costs (Playbook Pricing & Margin, contract price lists, the restricted pricing project), never an industry default. Below floor: say so with the number and what fixes it. Never put cost or margin in anything the customer sees.
1. **Quote requests with no quote out.** Any customer (contract or direct) who asked for pricing in clint@, sales@ (`mailboxOwnerEmail = sales@estmerch.com`) or a Pipedrive note, with no Printavo quote created since. These come first: build it in Printavo and get it in their hands today. Contract work (UGP etc.) counts.
2. **Quotes sent, not approved.** Printavo quotes 2+ business days old with no approval. Customer, quote #, total, days out. Suggest a call, not another email, if Printavo's reminder already went.
3. **Website leads.** Leads with no logged contact (Luke's automatic owner email doesn't count), then leads touched once with no next activity.
4. **Lead Drop.** Today's 5 from the Slack DM "Lead Drop: Day M/D": touched yet? Then older Lead Drop leads in the Pipedrive Leads inbox with no next activity, highest value first.
5. **Fall list / open deals (Rock 2: $105,437 by Nov 30).** Clint's open deals in Qualified (6) and Building Quote (7): no activity in 3+ business days, or no next activity at all. Show value, last touch date, and the deal's history in one line.
6. **Pipedrive hygiene.** Count of Clint's open leads and deals with no next activity (target 0). Deals that look won in Printavo (an order in the last 90 days) but are still open: "mark Won, link #order".

Before suggesting outreach on any account, check Printavo `search_orders` (limit 50+, read the END of the list, results are oldest first) for an order or quote in the last 90 days. If there is one, the deal is stale, not the customer: say "update Pipedrive", not "call".

## Output
- Top 5 by dollars at stake, then "N more". One line each: `Company · $value · last touch M/D · what to do`.
- Flag anything below the margin floor at the top. Offer to draft the follow-ups. Drafts go in clint@ Drafts in his voice (`clints-voice` skill; if it isn't installed: short, friendly, plain, no "circling back / touching base / hope this finds you well", no em dashes). Use only facts from Printavo, Pipedrive and the email thread. No prices or discounts unless Clint gives them.
- After he says he made a call, offer to log it in Pipedrive (activity + next activity with a date). Never log or change anything without his yes.

## Rules
- Contract and trade accounts (UGP / Underground, Chapman, Proforma, Left Hand, Big River, Baked T's, print shops, promo distributors) get fast quotes but no marketing or reorder pitches.
- Never contact End of The Line Cafe or Auto Art.
- Unpaid balances: Printavo `get_outstanding_balances` only. Don't chase new business from an account with a past-due balance without flagging it.
- Clint = Pipedrive user 26695756. Pipeline 2: 19 Leads, 6 Qualified, 7 Building Quote, 8 Quote Sent.
- Only what a tool showed you. If a connector fails, say which one in one line.

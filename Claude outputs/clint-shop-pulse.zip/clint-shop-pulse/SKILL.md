---
name: clint-shop-pulse
description: Clint's shop report to Luke at Est Merch. Use when Clint says "shop pulse", "send Luke the update", "weekly pulse", "L10 prep", or asks how the shop is doing. Pulls sales, production, customer issues and Rock progress from the tools and drafts a short report for Luke, with the decisions that need him on top.
---

# Shop Pulse — Est Merch, Clint → Luke

Clint is Luke's eyes and ears at the shop. Luke may not be in the building every day, so this report has to let him run the business from his phone in 2 minutes. Facts only, from the tools, with the decisions that need him first.

## Daily pulse (end of day, before Sundown)
Pull, then write a Slack DM for Luke (U0504FSDYB0). Show Clint the draft first; send only when Clint says so.

*Shop pulse [Day M/D]*
*Needs you* (only if any, top of the message): decisions only Luke can make. Below-floor pricing, a make-it-right past a free reprint, a big customer problem, a staffing issue, anything over $[threshold Luke sets].
*Sales*: quotes sent today (N, $), approved today (N, $), new website leads (N, all contacted? avg minutes to first contact), Lead Drop N/5 touched, fall list progress ($ won toward $105,437).
*Production*: today's jobs shipped/picked up (N), jobs at risk this week (#order, customer, why), misprints/reprints today (N, cause in a few words).
*Customers*: anyone upset or waiting, and what was done.
*Tomorrow*: the 1–3 things that matter most.

Sources: Printavo (quotes, orders, production schedule, statuses; `search_orders` is oldest-first and capped, use limit 50+ and read the end), Pipedrive (Clint = 26695756; deals, leads, activities), Outlook (clint@, sales@ with mailboxOwnerEmail), Slack #cx-daily (C0BJ5N0M2TV).

## Weekly pulse (Friday, or "L10 prep")
Same sections for the week, plus:
- **Rocks:** one word each (on track / off track) with the number behind it. Rock 2 is Clint's: $ won, deals open, deals touched this week.
- **Scorecard numbers Clint owns or can see:** website leads and speed to first contact, quotes sent vs approved, Lead Drop touched, open leads/deals with no next action (target 0), on-time jobs, misprints.
- **Issues for the L10:** the top 3, each one line, with who owns it.
- **Margin watch:** quotes sent below the margin floor this week (should be 0) and any job where cost ran over.

## Rules
- Lead with what needs Luke. If nothing does, say "Nothing needs you today."
- Never guess. If a number isn't in a tool, leave it out or say it couldn't be pulled.
- A stale record isn't proof something didn't happen. If Pipedrive or Printavo looks wrong, say "the record shows X, check with [person]" rather than concluding.
- Costs and margins are fine here (Luke and Clint only). Never include employee pay or HR details.
- Cash and bank balances are Luke's: leave them out unless Luke asks Clint to include them.

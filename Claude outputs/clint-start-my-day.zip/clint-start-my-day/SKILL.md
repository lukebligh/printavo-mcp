---
name: clint-start-my-day
description: Clint's morning run at Est Merch. Use when Clint says "start my day", "morning run", "what's on fire", or opens Claude first thing. Builds the at-risk job list for the 8:00 production meeting, surfaces overnight email and website leads that need him, and gets him ready for the day.
---

# Start My Day — Est Merch, Clint

Clint runs Customer Success and sales follow-through at Established Merch (screen print, embroidery, DTF, promo; St. Louis). The morning is the only part of his day tied to the clock. This skill gets him through it.

**Standing rule: sales opportunities trump everything.** A phone call, an inquiry or a quote request (contract or direct) beats anything on this list. The quote goes into Printavo and into the customer's hands the same day.

## The morning, in order

1. **Before the 8:00 production meeting: at-risk jobs.**
   - Printavo `get_production_schedule` for today through the next 5 business days, then `get_order_details` on those jobs.
   - Flag any job where the scheduled date is after the customer due date, or the due date is within 3 business days and goods, art or proof approval aren't done.
   - Add customer questions the crew needs answered (special instructions, placement, sizes not confirmed).
   - Output: a short list Clint can read out in the meeting. `#order · Customer · due M/D · the problem · what he needs from the crew`. Direct customers first. Max 8.

2. **After the meeting: overnight / weekend email.**
   - clint@ inbox, and sales@ (`mailboxOwnerEmail = sales@estmerch.com`): mail since 2 PM the previous weekday where the newest message is from outside estmerch.com and nobody at estmerch.com has replied.
   - Point him at the drafts already waiting in clint@ Drafts (his morning scheduled task builds them). Skim, fix, send.
   - Anything with no draft: offer to draft it now in his voice (`clints-voice` skill).

3. **By 9:00: website leads called and logged.**
   - "New Inquiry: Get a Quote" emails in sales@ from the last 2 business days. Skip TEST submissions.
   - For each, check Pipedrive for a call, email, note or activity logged after the submission time. Luke's automatic owner email ("Your … quote", sent minutes after the form) does NOT count. It told the lead Clint would call.
   - List every lead with nothing logged: name, company, phone, what they want, submitted when. These are calls, right now. If yesterday's leads aren't logged by 9:00, Luke's follow-up email goes out on that thread.

4. **Then: today's Lead Drop and #cx-daily.**
   - Today's Slack DM to Clint headed "Lead Drop: Day M/D" (5 leads). All 5 get touched today: call, email or text, logged in Pipedrive with a next activity.
   - #cx-daily (C0BJ5N0M2TV): stale-deal calls, lingering quotes, the CX digest.

After that the day runs off the list, not the clock. Point him to `clint-sales-sweep` and `clint-cx-sweep`, and remind him `clint-sundown` runs before he leaves.

## How to answer
- Lead with the action. Short lines: names, order numbers, dates, dollars.
- Max 5–8 items per section, highest dollars or nearest due date first. Say how many more.
- Only what a tool showed you. Never invent an order, a date or a dollar figure.
- Never send email, change a status, or edit a deal unless Clint asks in this chat. Drafting is fine when he asks.
- `search_orders` in Printavo returns results OLDEST FIRST and caps the list: use limit 50+ and read the end.
- If a connector is missing, say which in one line and give the manual step.

## Est Merch basics
- Clint = Pipedrive user 26695756. Pipeline 2 stages: 19 Leads, 6 Qualified, 7 Building Quote, 8 Quote Sent.
- The Six Promises: we hit the date (at risk? they hear it from us first) · nothing wrong ever ships · same-day answers · one proof · specs on file · if we miss, we make it right.
- Never contact End of The Line Cafe or Auto Art. Unpaid balances come only from Printavo `get_outstanding_balances`.

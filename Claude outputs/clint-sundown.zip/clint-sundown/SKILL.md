---
name: clint-sundown
description: Clint's Sundown Rule check at Est Merch. Use when Clint says "sundown", "before I leave", "end of day", "what's unanswered", or it's after 3:30 PM. Every email that needs a response gets one before he leaves, even if it's "got it, I'll get you an answer tomorrow." Drafts the replies and runs the end-of-day scorecard.
---

# Sundown — Est Merch, Clint

**The Sundown Rule:** nobody who reached out today goes to bed without hearing from us. If the full answer isn't ready, they get a holding reply with a real time: "Got it… I'll get you an answer tomorrow." (Promise 3: they hear back the same day.)

His scheduled Sundown task (3:45 PM) usually has drafts waiting already. This skill catches anything since then and runs the scorecard.

## Step 1: Find everything still waiting
- clint@ inbox and sales@ (`mailboxOwnerEmail = sales@estmerch.com`): threads from the last 3 business days where the newest message is from outside estmerch.com (customers, prospects, vendors, contract partners) and nobody at estmerch.com has replied since. Check luke@ Sent too if available, so you don't double up on something Luke answered.
- Skip newsletters, pitches, receipts, automated notifications, and Printavo status emails.
- Skip anything that already has a reply draft in clint@ Drafts; just remind him it's there.
- Missed calls and texts if Quo is connected.

## Step 2: Draft a reply for every one
In clint@ Drafts, on the thread, in his voice (`clints-voice` skill; if not installed: short, friendly, plain, no em dashes, no "circling back").
- **If the answer is in Printavo, Pipedrive or the thread** (status, due date, tracking, invoice link, "yes we can do that"): write the real answer.
- **If it needs a price, a decision, or someone else:** write a holding reply that says what happens next and when.
  - "Got it… I'll get you an answer tomorrow."
  - "Got your art, I'll have a proof back to you tomorrow."
  - "Checking with the crew on that date, I'll let you know first thing tomorrow."
  - On Friday, use "Monday" instead of "tomorrow".
- Never promise a price, date or capability that isn't in the data. Use `[price?]` or `[date?]` placeholders and flag them.
- sales@ items: draft from clint@ on the same thread (or a new message to the sender with "RE: [their subject]" if replying on the thread isn't possible).
- Every holding reply also becomes a Pipedrive activity for tomorrow ("Answer [Name]: [what]"), but only after Clint says yes.

## Step 3: End-of-day scorecard (yes / no from the tools)
1. Everyone who wrote or called today has a reply sent or drafted.
2. Website leads today: first contact logged (and how fast).
3. Lead Drop: N of 5 touched and logged.
4. Quotes requested today: all out?
5. Clint's open leads and deals with no next activity: N (target 0). Name the top 3 by value.
6. Tomorrow's at-risk jobs (Printavo production schedule vs due dates) for the 8:00 meeting.

## Output
*Sundown: N replies drafted in clint@ Drafts* (list: Name · what they asked · full answer / holding)
*Scorecard* (one line each)
*Tomorrow at 8* (at-risk jobs)
End with: "Send the drafts, set next actions, and you're done."

## Rules
- Never send anything. Drafts only, unless Clint says "send it".
- Never contact End of The Line Cafe or Auto Art.
- Only facts a tool showed you. If a connector fails, say which one in one line.
